package entity;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import main.GamePanel;
import main.KeyHandler;

public class Player extends Entity {

    GamePanel gp;
    KeyHandler keyH;

    public final int screenX;
    public final int screenY;

    public int hasKey = 0;
    public int coinCount = 0;
    public boolean questCompleted = false;

    public Player(GamePanel gp, KeyHandler keyH) {
        this.gp = gp;
        this.keyH = keyH;

        screenX = gp.screenWidth / 2 - (gp.tileSize / 2);
        screenY = gp.screenHeight / 2 - (gp.tileSize / 2);

        solidArea = new Rectangle();
        solidArea.x = 8;
        solidArea.y = 16;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y; 
        solidArea.width = 20;
        solidArea.height = 20;

        setDefaultValues();
        getPlayerImage();
    }

    public void setDefaultValues() {
        worldX = gp.tileSize * 97;
        worldY = gp.tileSize * 2;
        speed = 1;
        direction = "down";
    }

    public void getPlayerImage() {
        try {
            up1 = ImageIO.read(getClass().getResourceAsStream("/yes/up1.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/yes/up2.png"));
            up3 = ImageIO.read(getClass().getResourceAsStream("/yes/up3.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/yes/down1.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/yes/down2.png"));
            down3 = ImageIO.read(getClass().getResourceAsStream("/yes/down3.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/yes/left1.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/yes/left2.png"));
            left3 = ImageIO.read(getClass().getResourceAsStream("/yes/left3.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/yes/right1.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/yes/right2.png"));
            right3 = ImageIO.read(getClass().getResourceAsStream("/yes/right3.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {

        // ---------------- MOVEMENT ----------------
        if (keyH.upPressed || keyH.downPressed || keyH.leftPressed || keyH.rightPressed) {

            if (keyH.upPressed) direction = "up";
            else if (keyH.downPressed) direction = "down";
            else if (keyH.leftPressed) direction = "left";
            else if (keyH.rightPressed) direction = "right";

            spriteCounter++;
            if (spriteCounter > 60) {
                spriteNum++;
                if (spriteNum > 3) spriteNum = 1;
                spriteCounter = 0;
            }

            collisionOn = false;

            gp.cChecker.checkTile(this);

            int objIndex = gp.cChecker.checkObject(this, true);
            pickUpObject(objIndex);

            // ---------------- MOVEMENT ----------------
            if (!collisionOn) {
                switch (direction) {
                    case "up": worldY -= speed; break;
                    case "down": worldY += speed; break;
                    case "left": worldX -= speed; break;
                    case "right": worldX += speed; break;
                }
            }
        }

        // ---------------- NPC INTERACTION ----------------
        if (keyH.interactPressed) {
            if (gp.cChecker.checkNPCInteraction(this, gp.npc)) {
                if (coinCount >= 6) {
                    questCompleted = true;
                    gp.ui.notif("Quest completed! Door unlocked.");
                } else {
                    gp.ui.notif("Collect all 6 coins first!");
                }
            }
        }
    }

    public void pickUpObject(int i) {
        if (i != 999) {
            String objectName = gp.obj[i].name;

            switch (objectName) {
                case "Key":
                    hasKey++;
                    gp.obj[i] = null;
                    gp.ui.notif("You got a key!");
                    break;
                case "Door":
                    if (!questCompleted) {
                        gp.ui.notif("Finish the quest first!");
                        return;
                    }
                    if (hasKey > 0) {
                        gp.obj[i] = null;
                        hasKey--;
                        gp.ui.notif("Door opened!");
                    } else {
                        gp.ui.notif("You need a key!");
                    }
                    break;
                case "Chest":
                    gp.ui.gameFinished = true;
                    gp.obj[i] = null;
                    break;
                case "Boots":
                    gp.ui.notif("Speed up!");
                    gp.obj[i] = null;
                    speed++;
                    break;
                case "Coin":
                    coinCount++;
                    gp.obj[i] = null;
                    gp.ui.notif("Coin: " + coinCount + "/6");
                    if (coinCount >= 6) gp.ui.notif("Return to the NPC!");
                    break;
                default: break;
            }
        }
    }

    public void draw(Graphics2D g2) {
        BufferedImage image = null;

        switch (direction) {
            case "up":
                if(spriteNum == 1) image = up1;
                if(spriteNum == 2) image = up2;
                if(spriteNum == 3) image = up3;
                break;
            case "down":
                if(spriteNum == 1) image = down1;
                if(spriteNum == 2) image = down2;
                if(spriteNum == 3) image = down3;
                break;
            case "left":
                if(spriteNum == 1) image = left1;
                if(spriteNum == 2) image = left2;
                if(spriteNum == 3) image = left3;
                break;
            case "right":
                if(spriteNum == 1) image = right1;
                if(spriteNum == 2) image = right2;
                if(spriteNum == 3) image = right3;
                break;
        }

        g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
    }

}
